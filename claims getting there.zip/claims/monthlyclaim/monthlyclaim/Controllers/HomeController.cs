using Microsoft.AspNetCore.Mvc;
using monthlyclaim.Models;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace monthlyclaim.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly SqlQueries _db;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
            _db = new SqlQueries();
            _db.EnsureAllTables(); // Auto-create tables on first run
        }
        public IActionResult Index() => View();

        [HttpGet]
        public IActionResult SignUp() => View();

        [HttpPost]
        public IActionResult SignUp(User user)
        {
            if (ModelState.IsValid)
            {
                TempData["WelcomeMessage"] = "YOU ARE NOW A MEMBER!";
                return RedirectToAction("Login");
            }
            return View(user);
        }

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        public IActionResult Login(string username, string password, string role)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                ModelState.AddModelError("", "Please fill in all fields.");
                return View();
            }

            TempData["WelcomeMessage"] = $"Welcome back, {username}!";

            return role switch
            {
                "Lecturer" => View("Lecturer", new LecturerViewModel { Name = username }),
                "Coordinator" => RedirectToAction("Coordinator", new { username }),
                "Manager" => RedirectToAction("Manager", new { username }),
                _ => View()
            };
        }

        // --- Lecturer Submit Claim (GET) ---
        [HttpGet]
        public IActionResult SubmitClaim() => View();

        // --- Lecturer Submit Claim (POST) ---
        [HttpPost]
        public IActionResult SubmitClaim(DateTime claimDate, string lecturerFullName, string courseName,
                                         string moduleName, int hoursWorked, decimal hourlyRate,
                                         string additionalNotes, IFormFile supportDoc)
        {
            string filePath = null;

            if (supportDoc != null)
            {
                string uploadDir = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                if (!Directory.Exists(uploadDir)) Directory.CreateDirectory(uploadDir);
                filePath = Path.Combine(uploadDir, supportDoc.FileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    supportDoc.CopyTo(stream);
                }
            }

            _db.InsertClaim(claimDate, lecturerFullName, courseName, moduleName,
                            hoursWorked, hourlyRate, additionalNotes, filePath);

            TempData["Success"] = "Claim submitted successfully!";
            return RedirectToAction("SubmitClaim");
        }

        public IActionResult TrackClaim() => View();

        // --- Coordinator View ---
        [HttpGet]
        public IActionResult Coordinator(string username)
        {
            ViewBag.CoordinatorName = username;
            var claims = _db.GetAllClaims();
            return View(claims);
        }

        [HttpPost]
        public IActionResult UpdateClaimStatusCoordinator(int claimId, string actionType)
        {
            string status = actionType == "Approve" ? "Approved by Coordinator" : "Rejected by Coordinator";
            _db.UpdateClaimStatus(claimId, status);
            return RedirectToAction("Coordinator");
        }

        // --- Manager View ---
        [HttpGet]
        public IActionResult Manager(string username)
        {
            ViewBag.ManagerName = username;
            var claims = _db.GetAllClaims()
                .Select(c => new Manager
                {
                    ClaimId = c.ClaimId,
                    LecturerName = c.LecturerName,
                    SubmissionDate = c.SubmissionDate,
                    TotalAmount = c.TotalAmount,
                    Status = c.Status
                }).ToList();

            return View(claims);
        }

        [HttpPost]
        public IActionResult UpdateClaimStatusManager(int claimId, string actionType)
        {
            string status = actionType == "Approve" ? "Final Approved" : "Rejected by Manager";
            _db.UpdateClaimStatus(claimId, status);
            return RedirectToAction("Manager");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error() => View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

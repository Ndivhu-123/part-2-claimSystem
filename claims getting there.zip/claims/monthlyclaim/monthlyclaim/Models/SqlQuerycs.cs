﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace monthlyclaim.Models
{
    public class SqlQueries
    {
        // Your SQL Server connection string
        private readonly string connection = @"Server=(localDB)\claiming_systems;Database=claiming_systems;Trusted_Connection=True;";

        // ✅ Create required tables if they don't exist
        public bool EnsureAllTables()
        {
            try
            {
                using (SqlConnection connect = new SqlConnection(connection))
                {
                    connect.Open();

                    // Create Users table
                    string createUsers = @"
                    
                    CREATE TABLE Users (
                        UserId INT IDENTITY(1,1) PRIMARY KEY,
                        Username NVARCHAR(100) NOT NULL,
                        Email NVARCHAR(150) NOT NULL,
                        Password NVARCHAR(100) NOT NULL,
                        Role NVARCHAR(50) NOT NULL
                    );";

                    // Create SubmitClaims table
                    string createClaims = @"
                   
                    CREATE TABLE SubmitClaims (
                        ClaimId INT IDENTITY(1,1) PRIMARY KEY,
                        ClaimDate DATE NOT NULL,
                        LecturerFullName NVARCHAR(100) NOT NULL,
                        CourseName NVARCHAR(100) NOT NULL,
                        ModuleName NVARCHAR(100) NOT NULL,
                        HoursWorked INT NOT NULL,
                        HourlyRate DECIMAL(10,2) NOT NULL,
                        AdditionalNotes NVARCHAR(MAX),
                        SupportDocPath NVARCHAR(255),
                        Status NVARCHAR(50) DEFAULT 'Pending'
                    );";

                    new SqlCommand(createUsers, connect).ExecuteNonQuery();
                    new SqlCommand(createClaims, connect).ExecuteNonQuery();
                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error creating tables: " + ex.Message);
                return false;
            }
        }

        // ✅ Insert a new user
        public bool InsertUser(string username, string email, string password, string role)
        {
            try
            {
                using (SqlConnection connect = new SqlConnection(connection))
                {
                    connect.Open();
                    string insertQuery = @"INSERT INTO Users (Username, Email, Password, Role)
                                           VALUES (@Username, @Email, @Password, @Role)";

                    SqlCommand cmd = new SqlCommand(insertQuery, connect);
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@Password", password);
                    cmd.Parameters.AddWithValue("@Role", role);
                    cmd.ExecuteNonQuery();
                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error inserting user: " + ex.Message);
                return false;
            }
        }

        // ✅ Insert a new claim
        public bool InsertClaim(DateTime claimDate, string lecturerFullName, string courseName,
                                string moduleName, int hoursWorked, decimal hourlyRate,
                                string additionalNotes, string supportDocPath)
        {
            try
            {
                using (SqlConnection connect = new SqlConnection(connection))
                {
                    connect.Open();
                    string insertQuery = @"
                        INSERT INTO SubmitClaims 
                        (ClaimDate, LecturerFullName, CourseName, ModuleName, HoursWorked, HourlyRate, AdditionalNotes, SupportDocPath)
                        VALUES (@ClaimDate, @LecturerFullName, @CourseName, @ModuleName, @HoursWorked, @HourlyRate, @AdditionalNotes, @SupportDocPath)";

                    SqlCommand cmd = new SqlCommand(insertQuery, connect);
                    cmd.Parameters.AddWithValue("@ClaimDate", claimDate);
                    cmd.Parameters.AddWithValue("@LecturerFullName", lecturerFullName);
                    cmd.Parameters.AddWithValue("@CourseName", courseName);
                    cmd.Parameters.AddWithValue("@ModuleName", moduleName);
                    cmd.Parameters.AddWithValue("@HoursWorked", hoursWorked);
                    cmd.Parameters.AddWithValue("@HourlyRate", hourlyRate);
                    cmd.Parameters.AddWithValue("@AdditionalNotes", additionalNotes ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@SupportDocPath", supportDocPath ?? (object)DBNull.Value);
                    cmd.ExecuteNonQuery();
                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error inserting claim: " + ex.Message);
                return false;
            }
        }

        // ✅ Retrieve all claims
        public List<Coordinator> GetAllClaims()
        {
            var claims = new List<Coordinator>();
            try
            {
                using (SqlConnection connect = new SqlConnection(connection))
                {
                    connect.Open();
                    string query = "SELECT * FROM SubmitClaims";
                    SqlCommand cmd = new SqlCommand(query, connect);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        claims.Add(new Coordinator
                        {
                            ClaimId = Convert.ToInt32(reader["ClaimId"]),
                            LecturerName = reader["LecturerFullName"].ToString(),
                            CourseName = reader["CourseName"].ToString(),
                            ModuleName = reader["ModuleName"].ToString(),
                            HoursWorked = Convert.ToInt32(reader["HoursWorked"]),
                            HourlyRate = Convert.ToDecimal(reader["HourlyRate"]),
                            SubmissionDate = Convert.ToDateTime(reader["ClaimDate"]),
                            Status = reader["Status"].ToString()
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error reading claims: " + ex.Message);
            }
            return claims;
        }

        // ✅ Update claim status
        public bool UpdateClaimStatus(int claimId, string status)
        {
            try
            {
                using (SqlConnection connect = new SqlConnection(connection))
                {
                    connect.Open();
                    string query = "UPDATE SubmitClaims SET Status = @Status WHERE ClaimId = @ClaimId";
                    SqlCommand cmd = new SqlCommand(query, connect);
                    cmd.Parameters.AddWithValue("@Status", status);
                    cmd.Parameters.AddWithValue("@ClaimId", claimId);
                    cmd.ExecuteNonQuery();
                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error updating claim: " + ex.Message);
                return false;
            }
        }
    }
}

﻿namespace monthlyclaim.Models
{
    public class LecturerViewModel
    {
        public string Name { get; set; }
    }
}

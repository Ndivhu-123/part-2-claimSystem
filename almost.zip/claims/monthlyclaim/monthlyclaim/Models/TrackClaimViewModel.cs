﻿namespace monthlyclaim.Models
{
    using System;
    using System.ComponentModel.DataAnnotations;

    public class TrackClaimViewModel
    {
        [Required]
        public DateTime SubmissionDate { get; set; }

        [Required]
        public string CourseName { get; set; }

        [Required]
        public string ModuleName { get; set; }

        [Required]
        public int HoursWorked { get; set; }

        [Required]
        public decimal HourlyRate { get; set; }

        public decimal Total => HoursWorked * HourlyRate;

        public string? SupportDocPath { get; set; }


        [Required]
        public string Status { get; set; }
    }
}

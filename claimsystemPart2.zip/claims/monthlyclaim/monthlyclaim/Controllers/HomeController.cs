
using Microsoft.AspNetCore.Mvc;
using monthlyclaim.Models;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace monthlyclaim.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly SqlQuerycs _db; // ? Correct class name

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
            _db = new SqlQuerycs();
            _db.EnsureAllTables(); // Ensures tables exist only if missing
        }

        // ----------------- HOME PAGE -----------------
        public IActionResult Index() => View();

        [HttpGet]
        public IActionResult SignUp() => View();

        [HttpPost]
        public IActionResult SignUp(User user)
        {
            if (ModelState.IsValid)
            {
                bool success = _db.InsertUser(user.Username, user.Email, user.Password, user.Role);
                if (success)
                {
                    TempData["WelcomeMessage"] = "YOU ARE NOW A MEMBER!";
                    return RedirectToAction("Login");
                }

                ModelState.AddModelError("", "Error saving user data. Please try again.");
            }

            return View(user);
        }

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        public IActionResult Login(string username, string password, string role)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                ModelState.AddModelError("", "Please fill in all fields.");
                return View();
            }

            TempData["WelcomeMessage"] = $"Welcome back, {username}!";

            return role switch
            {
                "Lecturer" => View("Lecturer", new LecturerViewModel { Name = username }),
                "Coordinator" => RedirectToAction("Coordinator", new { username }),
                "Manager" => RedirectToAction("Manager", new { username }),
                _ => View()
            };
        }


        // ----------------- LECTURER DASHBOARD -----------------
        [HttpGet]
        public IActionResult Lecturer(string username)
        {
            if (string.IsNullOrEmpty(username))
            {
                ViewBag.Message = "Lecturer identity not found. Please log in.";
                return View();
            }

            TempData["LecturerName"] = username; // keep name available
            var claims = _db.GetClaimsByLecturer(username);

            return View("Lecturer", new LecturerViewModel { Name = username });
        }

        // ----------------- SUBMIT CLAIM -----------------
        [HttpGet]
        public IActionResult SubmitClaim()
        {
            ViewBag.LecturerName = TempData["LecturerName"];
            TempData.Keep("LecturerName"); // Keep for next request
            return View();
        }

        [HttpPost]
        public IActionResult SubmitClaim(DateTime claimDate, string lecturerFullName, string courseName,
                                         string moduleName, int hoursWorked, decimal hourlyRate,
                                         string additionalNotes, IFormFile supportDoc)
        {
            string filePath = null;

            // Save document if uploaded
            if (supportDoc != null && supportDoc.Length > 0)
            {
                string uploadDir = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                if (!Directory.Exists(uploadDir))
                    Directory.CreateDirectory(uploadDir);

                filePath = Path.Combine(uploadDir, supportDoc.FileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    supportDoc.CopyTo(stream);
                }
            }

            bool success = _db.InsertClaim(claimDate, lecturerFullName, courseName, moduleName,
                                           hoursWorked, hourlyRate, additionalNotes, filePath);

            TempData["Message"] = success
                ? "? Claim submitted successfully!"
                : "? Error submitting claim.";

            TempData["LecturerName"] = lecturerFullName;
            return RedirectToAction("TrackClaim", new { lecturerFullName });
        }

        // ----------------- TRACK CLAIM -----------------
        [HttpGet]
        public IActionResult TrackClaim(string lecturerFullName)
        {
            // Retrieve lecturer name from TempData if not passed directly
            if (string.IsNullOrEmpty(lecturerFullName))
                lecturerFullName = TempData["LecturerName"] as string;

            // Handle missing lecturer case
            if (string.IsNullOrEmpty(lecturerFullName))
            {
                ViewBag.Message = "Lecturer not found. Please log in.";
                return View(new List<TrackClaimViewModel>());
            }

            // ? Use correct method that returns TrackClaimViewModel
            var claims = _db.GetTrackClaimsByLecturer(lecturerFullName);

            // Handle case when no claims exist
            ViewBag.Message = claims.Count == 0 ? "No submitted claims yet." : null;

            TempData.Keep("LecturerName");
            return View(claims);
        }

        [HttpPost]
        public IActionResult TrackClaim()
        {
            // Get lecturer name from session-like TempData
            string lecturerFullName = TempData["LecturerName"] as string;

            if (string.IsNullOrEmpty(lecturerFullName))
            {
                ViewBag.Message = "Lecturer not found. Please log in.";
                return View(new List<TrackClaimViewModel>());
            }

            // ? Use correct method again
            var claims = _db.GetTrackClaimsByLecturer(lecturerFullName);

            // If no claims found
            ViewBag.Message = claims.Count == 0 ? "No submitted claims yet." : null;

            TempData.Keep("LecturerName");
            return View(claims);
        }


        
        // ----------------- COORDINATOR -----------------
        [HttpGet]
        public IActionResult Coordinator(string username)
        {
            ViewBag.CoordinatorName = username;
            var claims = _db.GetAllClaims();
            return View(claims);
        }

        [HttpPost]
        public IActionResult UpdateClaimStatusCoordinator(int claimId, string actionType)
        {
            string status = actionType == "Approve" ? "Approved by Coordinator" : "Rejected by Coordinator";
            _db.UpdateClaimStatus(claimId, status);
            return RedirectToAction("Coordinator", new { username = ViewBag.CoordinatorName });
        }

        // ----------------- MANAGER -----------------
        [HttpGet]
        public IActionResult Manager(string username)
        {
            ViewBag.ManagerName = username;

            var claims = _db.GetAllClaims()
                .Where(c => c.Status == "Approved by Coordinator" || c.Status == "Final Approved")
                .Select(c => new Manager
                {
                    ClaimId = c.ClaimId,
                    LecturerName = c.LecturerName,
                    SubmissionDate = c.SubmissionDate,
                    TotalAmount = c.TotalAmount,
                    Status = c.Status
                }).ToList();

            return View(claims);
        }

        [HttpPost]
        public IActionResult UpdateClaimStatusManager(int claimId, string actionType)
        {
            string status = actionType == "Approve" ? "Final Approved" : "Rejected by Manager";
            _db.UpdateClaimStatus(claimId, status);
            return RedirectToAction("Manager", new { username = ViewBag.ManagerName });
        }
        public IActionResult MoreInfo()
        {
            return View();
        }


        // ----------------- ERROR HANDLER -----------------
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error() =>
            View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

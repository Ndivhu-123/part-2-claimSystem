﻿  using System;
    using System.ComponentModel.DataAnnotations;

    namespace monthlyclaim.Models
    {
        // Represents claims visible to Programme Coordinators
        public class Coordinator
        {
            [Key]
            public int ClaimId { get; set; }

            public int LecturerId { get; set; }

            public string ModuleId { get; set; }

            public string LecturerName { get; set; }

            public string CourseName { get; set; }

            public string ModuleName { get; set; }

            public int HoursWorked { get; set; }

            public decimal HourlyRate { get; set; }

            public decimal TotalAmount => HoursWorked * HourlyRate;

            public DateTime SubmissionDate { get; set; }

            public DateTime CloseDate { get; set; }

            public string Status { get; set; }
        public string SupportDocPath { get; internal set; }
    }
    }

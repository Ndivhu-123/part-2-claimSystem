
    using monthlyclaim.Controllers;
using monthlyclaim.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using Xunit;

namespace monthlyclaim.Tests
    {
        public class HomeControllerTests
        {
            private readonly HomeController _controller;

            public HomeControllerTests()
            {
                var mockLogger = new Mock<ILogger<HomeController>>();
                _controller = new HomeController(mockLogger.Object);
            }

            [Fact]
            public void Index_ShouldReturnViewResult()
            {
                var result = _controller.Index();
                Assert.IsType<ViewResult>(result);
            }

            [Fact]
            public void SignUp_Get_ShouldReturnView()
            {
                var result = _controller.SignUp();
                Assert.IsType<ViewResult>(result);
            }

            [Fact]
            public void SignUp_Post_ShouldRedirectToLogin_OnValidData()
            {
                var user = new User
                {
                    Username = "Tester",
                    Email = "tester@example.com",
                    Password = "12345",
                    Role = "Lecturer"
                };

                var result = _controller.SignUp(user);
                Assert.IsType<RedirectToActionResult>(result);
            }

            [Fact]
            public void Login_ShouldReturnLecturerView_WhenRoleIsLecturer()
            {
                var result = _controller.Login("LecturerUser", "12345", "Lecturer");
                var viewResult = Assert.IsType<ViewResult>(result);
                Assert.Equal("Lecturer", viewResult.ViewName);
            }

            [Fact]
            public void SubmitClaim_ShouldRedirectToTrackClaim_OnSuccess()
            {
                var date = DateTime.Now;
                var result = _controller.SubmitClaim(date, "LecturerUser", "IT", "Module1", 4, 120, "Notes", null);
                var redirect = Assert.IsType<RedirectToActionResult>(result);
                Assert.Equal("TrackClaim", redirect.ActionName);
            }
        }
    }

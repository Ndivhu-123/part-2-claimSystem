﻿using monthlyclaim.Models;
using System;
using Xunit;

namespace monthlyclaim.Tests
{
    public class SqlQuerycsTests
    {
        private readonly SqlQuerycs _db = new SqlQuerycs();

        [Fact]
        public void InsertUser_ShouldReturnTrue()
        {
            bool result = _db.InsertUser("UnitTestUser", "test@unit.com", "pass", "Lecturer");
            Assert.True(result);
        }

        [Fact]
        public void InsertClaim_ShouldReturnTrue()
        {
            bool result = _db.InsertClaim(DateTime.Now, "UnitTester", "IT", "Module", 5, 200, "Notes", null);
            Assert.True(result);
        }
    }
}

